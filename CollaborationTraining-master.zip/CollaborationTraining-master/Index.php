<?php
echo "<h2> Selamat berlatih menjadi kolaborator </h2>";
echo "<h3>Isi Nama dan Nim Anda di bawah baris code ini</h3>";
echo "<h3>Ng. Satria Utomo W.P.(155610024)</h3>"

?>